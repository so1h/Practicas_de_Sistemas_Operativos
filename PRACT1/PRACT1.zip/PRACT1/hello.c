/* ----------------------------------------------------------------------- */
/*                (C) Pedro Pablo Lopez Rodriguez [bn0123]                 */
/* ----------------------------------------------------------------------- */

#include <stdio.h>                                      /* printf, getchar */

int main ( void )
{
    printf("\n Hola MINIX3 de parte de Pedro Pablo Lopez Rodriguez") ;
    getchar() ;
    return 0 ;
}
