rm -f *.o
cc -c e9_hack.s    -o e9_hack.o 
cc -c e9_hackstr.c -o e9_hackstr.o
cc -c e9_hackhex.c -o e9_hackhex.o
cc -c e9_hackint.c -o e9_hackint.o
cc -c e9_printf.c  -o e9_printf.o
cc -c vsprintf.c   -o vsprintf.o  
rm -f e9_system.a
ar ca e9_system.a *.o  
ar t e9_system.a

