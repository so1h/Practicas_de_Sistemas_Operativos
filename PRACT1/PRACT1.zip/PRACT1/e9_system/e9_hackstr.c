/* ----------------------------------------------------------------------- */
/*                              e9_hackstr.c                               */
/* ----------------------------------------------------------------------- */
/*                 implementacion modulo/unidad/biblioteca                 */
/* ----------------------------------------------------------------------- */

#include "e9_system.h"                                          /* e9_hack */

void e9_hackstr ( char * str )
{
    char car ;
    int i ;

    i = 0 ;
    while ((car = str[i]) != '\0')
    {
        e9_hack(car) ;
/*		
        if (car == '\n')
            e9_hack('\r') ;
*/		
        i++ ;
    }
    return ;
}
